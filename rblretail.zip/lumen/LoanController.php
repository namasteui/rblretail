<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\CustomerData;
use App\CustomerMaster;
use App\City;
use App\State;
use App\BankDetails;
use App\CustomerAddress;
use App\CustomerAppointment;
use App\CustomerKYC;
use App\Turnover;
use App\Timeslot;
use App\Religion;
use App\Category;
use App\Education;
use App\Occupation;
use Illuminate\Support\Facades\DB;
//use Illuminate\Support\Facades\Input;


class LoanController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->otpNum = 123456;
        $this->reference = '630c661f';
        $this->apiResponse = array();
        $this->invalidRequest = "Sorry! Something went wrong.";
        $this->invalidOTP = "Invalid OTP entered. Please enter correct OTP!";
        //$this->CustomerData = new CustomerData;
        $this->CustomerAddress = new CustomerAddress;
        $this->CustomerMaster = new CustomerMaster;
        $this->BankDetails = new BankDetails;
        $this->CustomerAppointment = new CustomerAppointment;
        $this->CustomerKYC = new CustomerKYC;
    }
    
    //Hits for landing page
    public function OTPPage($urn ,Request $request)
    {
        $URNumber = base64_decode($urn);

       /* $custData = json_decode($this->getCustomerMaster($URNumber),true);

        if ($custData[0]['processStatus'] == 1) {
            $data['status'] = 1;
            $data['message'] = 'Check Application Status';
        }else{*/
             //static data .. to be fetched from API of RBL
            $data = array();
            $data['URNumber'] = $URNumber;
            $data['name'] = 'Priyanka';
            $data['approvedCreditLimit'] = 75000;
            $data['mobile'] = '9887451151';
            $data['email'] = NULL;
            $CustomerMaster_flag = $this->saveCustomerMaster($URNumber,$data); 



            $data = array(
                'data'=>array(
                    'URNumber' =>  $URNumber,
                    'retailer_name' => 'Priyanka',
                    'approved_credit_limit' => 75000,
                    'mobile_number' => 9887451151,
                    'email' => NULL
                )
            );
            if($CustomerMaster_flag){
                 $data['status'] = 0;
                 $data['message'] = '';
            }else{
                $data['status'] = 1;
                $data['message'] = $this->invalidRequest;
            }
        //}


       
        
        return response()->json($data);           
    }
    // Get otp from service 
    public function otpGen($urn)
    {
        $URNumber = base64_decode($urn);
        $custData = json_decode($this->getCustomerMaster($URNumber),true);
        $data = array();
        
        $data['data'] = array(
                'URNumber' =>  $URNumber,
                'mobile_number' => $custData[0]['mobile'],
                'referenceNum' => $this->reference
            );
        //Response not recieved:::send status 1 and message Sorry. Something went wrong!
        $data['status'] = 0;
        $data['message'] = '';
        return response()->json($data);
    }
    //validates otp
    public function otpVal(Request $request)
    {
        $this->validate($request, [
            'referenceNum'=> 'required',
            'otp' => 'required',
            'URNumber' => 'required'
        ]);
        $data =array();
        //for local test purpose

        if ($request->input('referenceNum') == $this->reference && $request->input('otp') == $this->otpNum) {
            $custData = json_decode($this->getCustomerMaster($request->input('URNumber')),true);
            $data['data'] = array(
                'URNumber' =>  $request->input('URNumber'),
                'mobile_number' => $custData[0]['mobile']
            );
            $data['session'] = 1;
            $data['status'] = 0;
            $data['message'] = '';
        }else{
            $data['data'] = array();
            $data['status'] = 1;
            $data['message'] = $this->invalidOTP;
        }

        return response()->json($data);
    }
    //fetches credit limit from service
    public function creditLimit($urn)
    {
        $URNumber = base64_decode($urn);
        $data =array();

        $data['data'] = array(
                                "approved_credit_limit"=> "75000",
                                "tenure"=> "12",
                                "processing_fee"=> "2000",
                                "interest_rate" => "12.45"
                            );
        $data['status'] = 0;
        $data['message'] = '';
        
        return response()->json($data);
    }

    public function getCustomerDetails()
    {
        /*$someJSON = '[{"WebsiteRDFCustomerJourney": {
                       "data":    {
                          "URNumber": "8935154618383",
                          "CutomerDetails":       {
                             "URNumber": "8935154618383",
                             "retailer_name": "Priyanka",
                             "firm_name": "COCOON",
                             "approved_credit_limit": "75000",
                             "tenor": "12.000",
                             "pf_amt_excld_gst": "2000.000",
                             "convenience_fee_EXCLD_GST": "1000.000",
                             "franking_charges": "160.000",
                             "transaction_fee_EXCLD_GST": "1000.000",
                             "flag_cf": "Y",
                             "flag_pf": "N",
                             "flag_fc": "Y",
                             "flag_tc": "Y",
                             "cust_dob": "1982-10-27",
                             "pan1": "AAAAA0002L"
                          },
                          "AddressDetails": {},
                          "ScheduleDetails": {"timeSlots": []}
                       },
                       "status": "0",
                       "message": "0",
                       "pageName": "CustomerDetails"
                    }}]';
        return $someJSON;*/
        return array('status'=>0,'message'=>'','data'=>array());
    }

    //schedules appointment for customer
    public function scheduleAppointment(Request $request)
    {
        $data = array();
        
        $errFlag = 0;
        $this->validate($request, [
            'URNumber' => 'required',
            'appDate' => 'required', 
            'appTime' => 'required',
            'location' => 'required'
        ]);

        $URNumber = $request->input('URNumber');
        $custData = json_decode($this->getCustomerMaster($URNumber),true);

        $data['URNumber'] = $URNumber;
        $data['customerId'] = $custData[0]['customerId'];
        $data['appDate'] = $request->input('appDate');
        $data['appTime'] = $request->input('appTime');
        $data['location'] = $request->input('location');
        $appointmentFlag = $this->saveCustomerAppointment($URNumber,$data);
        unset($data);
        if($appointmentFlag){
            $data['data'] = array('URNumber'=>$URNumber);   
            $data['status'] = 0;
            $data['message'] = 'Data updated successfully';
        }else{
            $data['data'] = '';
            $data['status'] = 1;
            $data['message'] = $this->invalidRequest;
        }
        return response()->json($data);
    }

    //saves all type of addresses
    public function saveAddressDetails(Request $request)
    {
        //return json_encode($request);die;
        $data = array(); 
        $data['message'] = '';
        $data['data'] = array(); 
        $errFlag = 0;
        
        $office_pincode = trim($request->input('office_pincode'));
        $residence_pincode = trim($request->input('pincode')); 

        $this->validate($request, [
            'addressLine1'=>'required',
            'pincode' =>'required|numeric',
            'city' =>'required',
            'state' =>'required',
            'URNumber' => 'required',
            //'bank' => 'required', 
            //'accountHolder' => 'required',
            'accountNumber' => 'required|digits:18',
            'accountType' => 'required',
            'IFSC' => 'required'
        ]);

        //This is to validate the required address fields 

        if($request->input('office_addressLine1') == '')
            $data['message'] = 'Please input Office Address Line1!'; 
        elseif($request->input('office_city') == '') 
            $data['message'] = 'Please input Office City!'; 
        elseif($request->input('office_state') == '') 
            $data['message'] = 'Please input Office State!';
        elseif($office_pincode == '')
            $data['message'] = 'Please input Office Pincode!';
        elseif(!is_numeric($office_pincode)) 
            $data['message'] = 'Office Pincode should be numeric.';
        elseif(strlen($office_pincode) != 6 || $office_pincode == 0 )
            $data['message'] = 'Please input valid Office Pincode!';
        elseif(strlen($residence_pincode) != 6 || $residence_pincode == 0 )
            $data['message'] = 'Please input valid Residence Pincode!';

        

        //This is to save or edit address details
        if (empty($data['message'])) {
            $ur_number =  $request->input('URNumber');
            $custData = json_decode($this->getCustomerMaster($ur_number),true);
            //for residential address
            $addressLine1 = $request->input('addressLine1');
            $addressLine2 = $request->input('addressLine2');
            $landmark = $request->input('landmark');
            $pincode = $request->input('pincode');
            $city = $request->input('city');
            $district = $request->input('district');
            $state = $request->input('state');

            $data1 = array();
            $data1['URNumber'] = $ur_number;
            $data1['customerId'] = $custData[0]['customerId'];
            $data1['addressLine1'] = $addressLine1;
            $data1['addressLine2'] = $addressLine2;
            $data1['landmark'] = $landmark;
            $data1['pincode'] = $pincode;
            $data1['city'] = $city;
            $data1['district'] = $district;
            $data1['state'] = $state;
            $data1['addressType'] = 'Residence';
        
            $saveAddrFlag = $this->saveCustomerAddress($ur_number,$data1,'Residence');
            
            //for residential address
            $office_addressLine1 = $request->input('office_addressLine1');
            $office_addressLine2 = $request->input('office_addressLine2');
            $office_landmark = $request->input('office_landmark');
            $office_pincode = $request->input('office_pincode');
            $office_city = $request->input('office_city');
            $office_district = $request->input('office_district');
            $office_state = $request->input('office_state');
            
            $data2 = array();
            $data2['URNumber'] = $ur_number;
            $data2['customerId'] = $custData[0]['customerId'];
            $data2['addressLine1'] = $office_addressLine1;
            $data2['addressLine2'] = $office_addressLine2;
            $data2['landmark'] = $office_landmark;
            $data2['pincode'] = $office_pincode;
            $data2['city'] = $office_city;
            $data2['district'] = $office_district;
            $data2['state'] = $office_state;
            $data2['addressType'] = 'Office';

            $saveAddrFlag = $this->saveCustomerAddress($ur_number,$data2,'Office');
            
            //for customer bank details
            $bankDetails = array();
            $bankDetails['URNumber']=$ur_number;
            $bankDetails['customerId']=$custData[0]['customerId'];
            $bankDetails['bank'] = $request->input('bank');
            $bankDetails['accountHolder'] = $request->input('accountHolder');
            $bankDetails['accountNumber'] = $request->input('accountNumber');
            $bankDetails['accountType'] = $request->input('accountType');
            $bankDetails['IFSC'] = $request->input('IFSC');
            $bankFlag = $this->saveBankDetails($ur_number,$bankDetails);

            $data['status'] = 0;
            $data['message'] = 'Successfully updated!';
        }        
        else{
            $data['status'] = 1;
            if (empty($data['message'])) {
                $data['message'] = 'Please enter address details.';
            }
        }

        return response()->json($data);
    }
    
    //limit accepted by customer
    public function limitAcceptance($urn)
    {
        $data = array();
        $ur_number = base64_decode($urn);
        $dataAcc = array('offerAccepted'=>'Yes');
        $limFlag = $this->setCustomerAcceptance($ur_number,$dataAcc);
        if($limFlag){
            $data['data'] = array();
            $data['status'] = 0;
            $data['message'] = 'Data updated successfully';
        }else{
            $data['data'] = array();
            $data['status'] = 1;
            $data['message'] = $this->invalidRequest;
        }
        return response()->json($data);
    }
    //saves customer basic information
    public function saveCustomerBasic(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'dob'=>'required',
            'gender' => 'required',
            'pan'=> array( 'required', 'regex:/(^([A-Za-z]{5}\d{4}[A-Za-z]{1})?$)/u'),
            'mobile' => 'required|digits:10',
            'email' => 'email',
            'annualTurnover'=> 'required',
            'URNumber'=>'required'
        ]);
      
        $ur_number =  $request->input('URNumber');
        
        $CustomerMaster_flag = $this->saveCustomerMaster($ur_number,$request->all());
       
        if($CustomerMaster_flag){
             $data['data'] = array();
             $data['status'] = 0;
             $data['message'] = 'Data updated successfully';
               
        }else{
            $data['data'] = array();
            $data['status'] = 1;
            $data['message'] = $this->invalidRequest;
        }
        
        return response()->json($data);
    }

    
    //get states list
    public function getStateList()
    {
        $states = State::select('id', 'state_name')->get();
        return response()->json($states);
    }

    public function getTurnoverList()
    {
        $turnoverList = Turnover::select('at_id', 'annualTurnover')->get();
        return response()->json($turnoverList);
    }

    public function getTimeslotList()
    {
        $timeslotList = Timeslot::select('t_id', 'timeSlot')->get();
        return response()->json($timeslotList);
    }

    public function getReligionList()
    {
        $religionList = Religion::select('r_id', 'religion')->get();
        return response()->json($religionList);
    }

    public function getCategoryList()
    {
        $categoryList = Category::select('c_id', 'category')->get();
        return response()->json($categoryList);
    }

    public function getEducationList()
    {
        $educationList = Education::select('e_id', 'educationalQualification')->get();
        return response()->json($educationList);
    }

    public function getOccupationList()
    {
        $occupationList = Occupation::select('o_id', 'occupation')->get();
        return response()->json($occupationList);
    }    

    //get city list Occupation
    public function getCityList($stateId)
    {
        $cities = City::select('id', 'city_name')->where('state_id','=',$stateId)->get();
        return response()->json($cities);
    }

    //gives back appointment schedule on request
    public function getAppointmentSchedule($urn)
    {
        $data = array();
        $URNumber = base64_decode($urn);
        $custData = json_decode($this->getCustomerAppointment($URNumber),true);

        $data['URNumber'] = $URNumber;

        if (!empty($custData)) {
            $data['data'] = array(
                              'appDate' => $custData[0]['appDate'],
                              'appTime' => $custData[0]['appTime'],
                              'location' => $custData[0]['location'] 
                            );
            $data['status'] = 0;
            $data['message'] = '';
        }else{
            $data['data'] = array();
            $data['status'] = 1;
            $data['message'] = 'Your appointment is not scheduled.';
        }
        
        return response()->json($data);
    }

    //This function is used to complete C_KYC
    public function saveAdditionalDetails(Request $request)
    {
        $data = array();
        
        $this->validate($request, [
            //'URNumber'=>'required',
            //'motherMaidenName' =>'required', 
            //'fatherSpouseName' =>'required',
            //'maritalStatus' =>'required', 
            //'category' =>'required', 
            //'religion' =>'required', 
            //'education' =>'required', 
            //'citizenship' =>'required',
            //'residentialStatus' =>'required',
            //'STDCode' =>'required|numeric',
            'phone' =>'digits:10'
            //'phone' =>'required|digits:10', 
            //'incorporationDate' =>'required'
        ]);

        $ur_number =  $request->input('URNumber');
        $custData = json_decode($this->getCustomerMaster($ur_number),true);

        $data['URNumber'] = $ur_number;
        $data['customerId'] = $custData[0]['customerId'];
        $data['title'] = $request->input('title');
        $data['name'] = $request->input('name');
        $data['motherMaidenName'] = $request->input('motherMaidenName');
        $data['fatherSpouseName'] = $request->input('fatherSpouseName');
        $data['maritalStatus'] = $request->input('maritalStatus');
        $data['category'] = (int)$request->input('category');
        $data['religion'] = (int)$request->input('religion');
        $data['education'] = (int)$request->input('education');
        $data['citizenship'] = $request->input('citizenship');
        $data['residentialStatus'] = $request->input('residentialStatus');
        $data['STDCode'] = $request->input('STDCode');
        $data['phone'] = $request->input('phone');
        $data['businessEntity'] = $request->input('businessEntity');
        $data['incorporationDate'] = $request->input('incorporationDate');
        $data['incorporationDate'] = $data['incorporationDate'] ? $data['incorporationDate'] : '1970-01-01';
        $data['businessVintage'] = $request->input('businessVintage');
        $data['occupationType'] = (int)$request->input('occupationType');
        $data['GST'] = $request->input('GST');

        $cKYC = $this->saveCustomerKYC($ur_number,$data);

        if($cKYC){
             $data['data'] = array();
             $data['status'] = 0;
             $data['message'] = 'Data updated successfully';
             $this->saveCustomerMaster($ur_number,array('processStatus'=>'1'));
        }else{
            $data['data'] = array();
            $data['status'] = 1;
            $data['message'] = $this->invalidRequest;
        }

        return response()->json($data);
    }

    //fetch customer details while coming back to tell us yourself page
    public function getCustomerData($urn)
    {
        $data = array();
        $URNumber = base64_decode($urn);

        $custData = json_decode($this->getData($URNumber,'tbl_customer_master'),true);
        $data['data'] = array(
            'name' => $custData[0]['name'],
            'dob' => $custData[0]['dob'],
            'pan' => $custData[0]['pan'],
            'gender' => $custData[0]['gender'],
            'mobile' => $custData[0]['mobile'],
            'email' => $custData[0]['email'],
            'annualTurnover' => $custData[0]['annualTurnover']
        );

        $data['status'] = 0;
        $data['message'] = '';
        return response()->json($data);
    }

    //Not required for now
    public function getCreditLimit($urn)
    {
        $data = array();
        $URNumber = base64_decode($urn);

        $custData = json_decode($this->getData($URNumber,'tbl_customer_master'),true);
        $data['data'] = array(
            'approvedCreditLimit' => $custData[0]['approvedCreditLimit'],
            'annualRate' => $custData[0]['annualRate'],
            'tenure' => $custData[0]['tenure'],
            'processingFees' => $custData[0]['processingFees'],
        );

        $data['status'] = 0;
        $data['message'] = '';
        return response()->json($data);
    }

    public function getCustomerAddress($urn)
    {
        $data = array();
        $URNumber = base64_decode($urn);

        $custAddress = json_decode($this->getData($URNumber,'tbl_customer_address'),true);
        /*Here we get address information of the customer*/
        for ($i=0; $i < count($custAddress); $i++) { 
            $data['data'][$custAddress[$i]['addressType']] = array(
                'addressLine1' => $custAddress[$i]['addressLine1'],
                'addressLine2' => $custAddress[$i]['addressLine2'],
                'landmark' => $custAddress[$i]['landmark'],
                'pincode' => $custAddress[$i]['pincode'],
                'city' => $custAddress[$i]['city'],
                'district' => $custAddress[$i]['district'],
                'state' => $custAddress[$i]['state']
            );
        }

        $custBanks = json_decode($this->getData($URNumber,'customer_bank_details'),true);
        /*Here we get the bank details of the customer*/
        if ($custBanks) {
           $data['data']['BankDetails'] = array(
                'bank' => $custBanks[0]['bank'],
                'accountHolder' => $custBanks[0]['accountHolder'],
                'accountNumber' => $custBanks[0]['accountNumber'],
                'accountType' => $custBanks[0]['accountType'],
                'IFSC' => $custBanks[0]['IFSC']
           ); 
        }

        $data['status'] = 0;
        $data['message'] = '';
        return response()->json($data);
    }

    //Not required for now
    public function getAppointmentDetails($urn)
    {
        $data = array();
        $URNumber = base64_decode($urn);

        $custAppointment = json_decode($this->getData($URNumber,'customer_appointment'),true);
        if ($custAppointment) {
                $data['data'] = array(
                'appDate' => $custAppointment[0]['appDate'],
                'appTime' => $custAppointment[0]['appTime'],
                'location' => $custAppointment[0]['location']
            );

            $data['status'] = 0;
            $data['message'] = '';
        }else{
            $data['data'] = array();
            $data['status'] = 1;
            $data['message'] = $this->invalidRequest;   
        }
        
        return response()->json($data);
    }

    public function getApplicationStatus($urn)
    {
        $data = array();
        $URNumber = base64_decode($urn);
        $custData = json_decode($this->getCustomerMaster($URNumber),true);
        $data['data'] = array('name' => $custData[0]['name']);

        if ($custData[0]['processStatus'] == 1) {
            $data['status'] = 1;
            $data['message'] = 'Check Application Status';
        }else{
            $data['status'] = 0;
            $data['message'] = '';
        }

        return response()->json($data);
    }

    public function getCKYC($urn)
    {
        $data = array();
        $URNumber = base64_decode($urn);

        $custKYC = json_decode($this->getData($URNumber,'tbl_customer_kyc'),true);
        if ($custKYC) {
            $data['data'] = array(
                'title' => $custKYC[0]['title'],
                'name' => $custKYC[0]['name'],
                'motherMaidenName' => $custKYC[0]['motherMaidenName'],
                'fatherSpouseName' => $custKYC[0]['fatherSpouseName'],
                'maritalStatus' => $custKYC[0]['maritalStatus'],
                'category' => $custKYC[0]['category'],
                'religion' => $custKYC[0]['religion'],
                'education' => $custKYC[0]['education'],
                'citizenship' => $custKYC[0]['citizenship'],
                'residentialStatus' => $custKYC[0]['residentialStatus'],
                'STDCode' => $custKYC[0]['STDCode'],
                'phone' => $custKYC[0]['phone'],
                'businessEntity' => $custKYC[0]['businessEntity'],
                'incorporationDate' => $custKYC[0]['incorporationDate'],
                'businessVintage' => $custKYC[0]['businessVintage'],
                'occupationType' => $custKYC[0]['occupationType'],
                'GST' => $custKYC[0]['GST']
            );
            //$data['data'] = $custKYC[0];
            $data['status'] = 0;
            $data['message'] = '';
        }else{
            $data['data'] = array();
            $data['status'] = 1;
            $data['message'] = $this->invalidRequest;   
        }

        return response()->json($data);
    }
    

    /*
    * All common function starts here
    */
    //this commom function is used to store data in table tbl_customer_master
    private function saveCustomerMaster($ur_number,$data){
        $find_customer = CustomerMaster::where('URNumber' , '=', $ur_number)->get();
        if(sizeof($find_customer) > 0){
            $condition = array('URNumber'=>$ur_number);
            return $this->CustomerMaster->where($condition)->update($data);
        }else{
            return $this->CustomerMaster->create($data);
        }
    }
    //this is a common function to save page specific data
    private function saveCustomerAddress($ur_number,$data,$address_type){
        $find_customer_address = CustomerAddress::where('URNumber' , '=', $ur_number)->where('addressType','=',$address_type)->get();
        if(sizeof($find_customer_address) > 0){
            $condition = array('URNumber'=>$ur_number,'addressType'=>$address_type);
            return $this->CustomerAddress->where($condition)->update($data);
        }else{
            return $this->CustomerAddress->create($data);
        }
    }
    //saves or edits bank details
    private function saveBankDetails($ur_number,$data){
        $find_bank_details = BankDetails::where('URNumber' , '=', $ur_number)->get();
        if(sizeof($find_bank_details) > 0){
            $condition = array('URNumber'=>$ur_number);
            return $this->BankDetails->where($condition)->update($data);
        }else{
            return $this->BankDetails->create($data);
        }
    }
    //updates customer acceptance
    private function setCustomerAcceptance($ur_number,$data){

        $find_customer = CustomerMaster::where('URNumber' , '=', $ur_number)->update($data);
        return $find_customer;
    }

   //get customer information from customer master table
    private function getCustomerMaster($ur_number){
        $find_customer = CustomerMaster::where('URNumber' , '=', $ur_number)->get();
        return $find_customer;
    }
    //saves or update customer appointment schedule
    private function saveCustomerAppointment($ur_number,$data)
    {
        $find_appointment_details = CustomerAppointment::where('URNumber' , '=', $ur_number)->get();
        if(sizeof($find_appointment_details) > 0){
            $condition = array('URNumber'=>$ur_number);
            return $this->CustomerAppointment->where($condition)->update($data);
        }else{
            return $this->CustomerAppointment->create($data);
        }
    }

    //get customer information from customer appointment table
    private function getCustomerAppointment($ur_number){
        $find_customer_app = CustomerAppointment::where('URNumber' , '=', $ur_number)->get();
        return $find_customer_app;
    }

    //this commom function is used to store data in table tbl_customer_data
    private function saveCustomerData($pageName,$ur_number,$data){

        $find_customer_data = CustomerData::where('URNumber' , '=', $ur_number)
                                ->where('pageName' ,'=', $pageName)
                                ->get();
       
        if(sizeof($find_customer_data) > 0){
            $condition = array('URNumber'=>$ur_number);
            $value = array();
            $value['custData'] = json_encode($data);
            $value['mobile'] = $data['mobile'];
            return $this->CustomerData->where($condition)->update($value);

        }else{

             $value = array();
             $value['custData'] = json_encode($data);
             $value['URNumber'] = $ur_number;
             $value['mobile'] = $data['mobile'];
             $value['pageName'] = $pageName;
             return  $this->CustomerMaster->create($value);
        }
    } 

    private function saveCustomerKYC($ur_number,$data)
    {
      $find_appointment_details = CustomerKYC::where('URNumber' , '=', $ur_number)->get();
        if(sizeof($find_appointment_details) > 0){
            $condition = array('URNumber'=>$ur_number);
            return $this->CustomerKYC->where($condition)->update($data);
        }else{
            return $this->CustomerKYC->create($data);
        }
    }

    private function getData($ur_number,$table_name)
    {
        $user_data = DB::table($table_name)
                    ->where('URNumber','=',$ur_number)
                    ->get();

        return $user_data;
    }  
}
