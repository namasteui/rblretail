<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});
//for database connection testing
$router->get('/database-test', function () {
    if ( DB::connection()->getDatabaseName() ) {
        echo 'Connected successfully to database: ' . DB::connection()->getDatabaseName();
    }
});

//creditLimit..limitAcceptance ... getAppointmentSchedule..saveAdditionalDetails..
$router->get('getStateList/','LoanController@getStateList');
$router->get('getCityList/{stateId}','LoanController@getCityList');
$router->get('creditLimit/{urn}','LoanController@creditLimit');
$router->post('saveCustomerBasic/','LoanController@saveCustomerBasic');
$router->post('saveCustomerData/','LoanController@saveCustomerData');
$router->get('OTPPage/{urn}','LoanController@OTPPage');
$router->get('otpGen/{urn}','LoanController@otpGen');
$router->post('otpVal/','LoanController@otpVal');
$router->get('limitAcceptance/{urn}','LoanController@limitAcceptance');
$router->post('saveAddressDetails/','LoanController@saveAddressDetails');
$router->post('scheduleAppointment/','LoanController@scheduleAppointment');
$router->get('getAppointmentSchedule/{urn}','LoanController@getAppointmentSchedule');
$router->post('saveAdditionalDetails/','LoanController@saveAdditionalDetails');
$router->get('getCustomerData/{urn}','LoanController@getCustomerData');
$router->get('getCreditLimit/{urn}','LoanController@getCreditLimit');
$router->get('getCustomerAddress/{urn}','LoanController@getCustomerAddress');
$router->get('getAppointmentDetails/{urn}','LoanController@getAppointmentDetails');
$router->get('getApplicationStatus/{urn}','LoanController@getApplicationStatus');
$router->get('getTurnoverList/','LoanController@getTurnoverList');
$router->get('getTimeslotList/','LoanController@getTimeslotList');
$router->get('getReligionList/','LoanController@getReligionList');
$router->get('getCategoryList/','LoanController@getCategoryList');
$router->get('getEducationList/','LoanController@getEducationList');
$router->get('getOccupationList/','LoanController@getOccupationList');