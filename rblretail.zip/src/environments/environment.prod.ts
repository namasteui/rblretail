export const environment = {
  production: true,
  RblRetailLoanURL: 'http://35.154.106.80/rbl/rblbe'
};
