import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GetOtpComponent } from './container/get-otp/get-otp.component';
import { VerifyOtpComponent } from './container/verify-otp/verify-otp.component';
import { AboutYourselfComponent } from './container/about-yourself/about-yourself.component';
import { CreditLimitComponent } from './container/credit-limit/credit-limit.component';
import { AddressDetailsComponent } from './container/address-details/address-details.component';
import { ScheduleAppointmentComponent } from './container/schedule-appointment/schedule-appointment.component';
import { AdditionalDetailsComponent } from './container/additional-details/additional-details.component';
import { ErrorComponent } from './container/error/error.component';
import { CheckstatusComponent } from './container/checkstatus/checkstatus.component';
import { AuthGuard } from './core/auth/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: GetOtpComponent
  },
  {
    path: ':urn',
    component: GetOtpComponent
  },
  {
    path: 'rbl/verifyOtp',
    component: VerifyOtpComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'rbl/customerDetails',
    component: AboutYourselfComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'rbl/creditLimit',
    component: CreditLimitComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'rbl/addressDetails',
    component: AddressDetailsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'rbl/scheduleAppointment',
    component: ScheduleAppointmentComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'rbl/additionalDetails',
    component: AdditionalDetailsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'rbl/checkstatus',
    component: CheckstatusComponent
  },
  {
    path: '**',
    component: ErrorComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
