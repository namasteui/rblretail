import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest} from '@angular/common/http';
import { Observable, pipe } from 'rxjs';
import { tap, finalize } from 'rxjs/operators';
import { LoaderService } from '../../services/loader.service';

@Injectable()
export class APIInterceptor implements HttpInterceptor {

    constructor( 
        private loaderService: LoaderService
    ) {}

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {     
        const apiReq = req.clone();
        return next.handle(apiReq)
                .pipe(
                    tap(() => this.loaderService.show()),
                    finalize( () => this.loaderService.hide())
                );
    }
}
