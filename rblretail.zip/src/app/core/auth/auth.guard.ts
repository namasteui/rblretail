import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { RblserviceService } from '../../services/rblservice.service';


@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor( private rblserv: RblserviceService, private router: Router) {  }

  canActivate(next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
      this.rblserv.getApplicationStatus()
      .subscribe(
        res => {
          if(res['status'] == 0){
            return true;
          } else {
            this.router.navigate(['rbl/checkstatus']);
            return false;
          }        
        }
      );
    return true;
  }
}
