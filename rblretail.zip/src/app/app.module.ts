import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { APIInterceptor } from './core/interceptor/api-interceptor';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { GetOtpComponent } from './container/get-otp/get-otp.component';
import { VerifyOtpComponent } from './container/verify-otp/verify-otp.component';
import { AboutYourselfComponent } from './container/about-yourself/about-yourself.component';
import { CreditLimitComponent } from './container/credit-limit/credit-limit.component';
import { AddressDetailsComponent } from './container/address-details/address-details.component';
import { LoaderComponent } from './loader/loader.component';
import { FooterComponent } from './footer/footer.component';
import { ScheduleAppointmentComponent } from './container/schedule-appointment/schedule-appointment.component';
import { AdditionalDetailsComponent } from './container/additional-details/additional-details.component';
import { ErrorComponent } from './container/error/error.component';
import { CheckstatusComponent } from './container/checkstatus/checkstatus.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    GetOtpComponent,
    VerifyOtpComponent,
    AboutYourselfComponent,
    CreditLimitComponent,
    AddressDetailsComponent,
    LoaderComponent,
    FooterComponent,
    ScheduleAppointmentComponent,
    AdditionalDetailsComponent,
    ErrorComponent,
    CheckstatusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgbModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: APIInterceptor,
      multi: true
    }
  ],
  exports : [
    LoaderComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
