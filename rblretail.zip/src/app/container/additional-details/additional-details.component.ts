import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,FormControl,Validators, Validator } from '@angular/forms';
import { RblserviceService } from '../../services/rblservice.service';
import { Router } from '@angular/router';

import { NgbDatepickerConfig, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { padNumber, NgbDateCustomParserFormatter } from '../../core/util/ngb-date-customer-parser-format';

@Component({
  selector: 'app-additional-details',
  templateUrl: './additional-details.component.html',
  styleUrls: ['./additional-details.component.css'],
  providers: [{provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter}]
})
export class AdditionalDetailsComponent implements OnInit {

  formclass;
  msg;
  error_msg;
  error_title;
  showForm;
  showPage;
  schedule_dt:String;
  slot:String;
  addDetailsForm: FormGroup;
  maxDate;
  religionList : {};
  educationList: {};
  categoryList: {};
  occupationList:{};
  constructor(
    private fb: FormBuilder,
    private rblserv: RblserviceService,
    private router: Router
  ) { }

  ngOnInit() {    
    if(!this.rblserv.chkRBLSteps()){
      this.router.navigate(['/']);
    } else {
      this.appointmentSchedule();
      this.rblserv.getReligionList().subscribe(data => {
        this.religionList = data;
        this.rblserv.getEducationList().subscribe(data1 => {
          this.educationList = data1;
          this.rblserv.getCategoryList().subscribe(data2 => {
            this.categoryList = data2;
            this.rblserv.getOccupationList().subscribe(data3 => {
              this.occupationList = data3;
            });
          });
        });
      });
    }
    
    let todaysDt = padNumber((new Date()).getDate()) + '/' + padNumber(((new Date()).getMonth() + 1)) + '/' + (new Date()).getFullYear();
    this.maxDate = {year: (new Date()).getFullYear(), month: ((new Date()).getMonth() + 1), day: (new Date()).getDate()};
    this.createAppointmentform();

    

    

    

    
  }

  createAppointmentform(){
    this.addDetailsForm = this.fb.group({
      title:  [''],
      name:  [''],
      motherMaidenName:[''],
      fatherSpouseName:[''],
      maritalStatus:[''],
      category:[''],
      religion:[''],
      education:[''],
      citizenship:[''],
      residentialStatus:[''],
      STDCode:[''],
      phone:[''],
      businessEntity:[''],
      incorporationDate:[''],
      businessVintage:[''],
      occupationType:[''],
      GST:['']
    });

    this.rblserv.getCustomerData().subscribe(response => {
      this.addDetailsForm.controls['name'].setValue(response['data']['name']);
    })
  }

  appointmentSchedule(){
    this.rblserv.getAppointmentSchedule()
    .subscribe( res => {
      if(res && res['status'] == 0){
        this.schedule_dt = res['data']['appDate'];
        this.schedule_dt = this.schedule_dt.replace(/-/g,".");
        this.slot = res['data']['appTime'];
        this.showPage = true;
        this.showForm = true;
      } else {
        this.showPage = false;
        this.error_msg = res['message'];
        this.error_title = 'Sorry!';
      }
    });
  }

  saveAdditionalDetails(v){
    let formdata = new FormData();
    let URNumber = this.rblserv.getURNumber();
    let incorporationDatedb = v.incorporationDate;
    let incorporationDate;
    if(incorporationDatedb){
      incorporationDate = `${incorporationDatedb.year}-${padNumber(incorporationDatedb.month)}-${padNumber(incorporationDatedb.day)}`;
    }
    else {
      incorporationDate = '';
    }
    
    formdata.append('title', v.title);
    formdata.append('name', v.name);
    formdata.append('motherMaidenName', v.motherMaidenName);
    formdata.append('fatherSpouseName', v.fatherSpouseName);
    formdata.append('maritalStatus', v.maritalStatus);
    formdata.append('category', v.category);
    formdata.append('religion', v.religion);
    formdata.append('education', v.education);
    formdata.append('citizenship', v.citizenship);
    formdata.append('residentialStatus', v.residentialStatus);
    formdata.append('STDCode', v.STDCode);
    formdata.append('phone', v.phone);
    formdata.append('businessEntity', v.businessEntity);
    formdata.append('incorporationDate', incorporationDate);
    formdata.append('businessVintage', v.businessVintage);
    formdata.append('occupationType', v.occupationType);
    formdata.append('GST', v.GST);
    formdata.append('URNumber', URNumber);

    this.rblserv.saveAdditionalDetails(formdata)
    .subscribe( 
      res => {
        if(res['status'] == 0){
          this.formclass = 'success';
          this.msg = res['message'];
          this.showForm = false;  
          //localStorage.removeItem('RBL');
          localStorage.removeItem('RSTEP');
        } else {
          this.formclass = 'error';
          this.msg = res['message'];
        }
      },
      error => {
        this.formclass = 'error';
        if(error.error.phone){
          this.msg = error.error.phone;
        }else{
           this.msg = '';
        }
        /*elseif(error.error.motherMaidenName){
          this.msg = error.error.motherMaidenName;
        } else if(error.error.fatherSpouseName){
          this.msg = error.error.fatherSpouseName;
        } else if(error.error.maritalStatus){
          this.msg = error.error.maritalStatus;
        } else if(error.error.category){
          this.msg = error.error.category;
        } else if(error.error.religion){
          this.msg = error.error.religion;
        } else if(error.error.education){
          this.msg = error.error.education;
        } else if(error.error.citizenship){
          this.msg = error.error.citizenship;
        } else if(error.error.residentialStatus){
          this.msg = error.error.residentialStatus;
        } else if(error.error.STDCode){
          this.msg = error.error.STDCode;
        } else if(error.error.incorporationDate){
          this.msg = error.error.incorporationDate;
        } else {
          this.msg = '';
        }  */             
      }
    );

  }
  

}
