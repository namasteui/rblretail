import { Component, OnInit } from '@angular/core';
import { RblserviceService } from '../../services/rblservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-checkstatus',
  templateUrl: './checkstatus.component.html',
  styleUrls: ['./checkstatus.component.css']
})
export class CheckstatusComponent implements OnInit {

  retailer_name
  constructor(private rblserv: RblserviceService, private router: Router) { }

  ngOnInit() {
    this.rblserv.getApplicationStatus().subscribe(
      res=>{
        
        if(res['status'] == 0){
          this.router.navigate(['']);          
        } else {
          this.retailer_name = res['data']['name'];
        }        
      }
    )
  }

}
