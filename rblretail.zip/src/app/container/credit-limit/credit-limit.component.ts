import { Component, OnInit } from '@angular/core';
import { RblserviceService } from '../../services/rblservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-credit-limit',
  templateUrl: './credit-limit.component.html',
  styleUrls: ['./credit-limit.component.css']
})
export class CreditLimitComponent implements OnInit {
  formclass;
  msg;
  error_msg;
  success = true;
  approved_credit_limit;
  interest_rate;
  processing_fee;
  tenure;

  constructor(
    private rblserv: RblserviceService,
    private router: Router
  ) { }

  ngOnInit() {
    if(!this.rblserv.chkRBLSteps()){
      this.router.navigate(['/']);
    } else {
      this.creditLimit();
    }    
  }

  creditLimit(){
    this.rblserv.getCreditLimit()
    .subscribe( res => {
      if(res && res['status'] == 0){
        this.approved_credit_limit = res['data']['approved_credit_limit'] || 0;
        this.interest_rate = res['data']['interest_rate'] || 0;
        this.processing_fee = res['data']['processing_fee'] || 0;
        this.tenure = res['data']['tenure'] || 0;
      } else {
        this.success = false;
        this.error_msg = res['message'];
      }
    },
    error => {
      this.success = false;
      this.error_msg = 'Sorry! Something went wrong.';
    });
  }

  limitAcceptance(){
    this.rblserv.limitAcceptance()
    .subscribe( res => {
      if(res && res['status'] == 0){
        this.rblserv.setAppointmentStep('addressDetails');
        this.router.navigate(['rbl/addressDetails']);        
      } else {
        this.formclass = 'error';
        this.msg = res['message'];
      }
    });         
  }

}
