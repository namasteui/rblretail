import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, Validator } from '@angular/forms';
import { RblserviceService } from '../../services/rblservice.service';
import { Router } from '@angular/router';

import { NgbDatepickerConfig, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { padNumber, NgbDateCustomParserFormatter, ltrim } from '../../core/util/ngb-date-customer-parser-format';

@Component({
  selector: 'app-schedule-appointment',
  templateUrl: './schedule-appointment.component.html',
  styleUrls: ['./schedule-appointment.component.css'],
  providers: [{ provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }]
})
export class ScheduleAppointmentComponent implements OnInit {

  scheduleAppoint: FormGroup;
  msg: string;
  formclass;
  minDate;
  appDate;
  appTime;
  location;
  timeSlotList: {};
  constructor(private fb: FormBuilder,
    private rblserv: RblserviceService,
    private router: Router) { }

  ngOnInit() {
    if (!this.rblserv.chkRBLSteps()) {
      this.router.navigate(['/']);
    } else {
      this.rblserv.getAppointmentSchedule()
        .subscribe(res => {
          if (res && res['status'] == 0) {
            let appDate = res['data']['appDate'] || '';
            if (appDate) {
              this.appDate = appDate.split("-");
              let y = parseInt(this.appDate[0]);
              let m = parseInt(ltrim(this.appDate[1], '0'));
              let d = parseInt(ltrim(this.appDate[2], '0'));
              this.scheduleAppoint.controls['appDate'].setValue({ year: y, month: m, day: d });
            }

            this.appTime = res['data']['appTime'];
            this.location = res['data']['location'];

            this.scheduleAppoint.controls['appTime'].setValue(this.appTime);
            this.scheduleAppoint.controls['location'].setValue(this.location);
          }
        });
      this.getTimeslotList();
    }

    this.minDate = { year: (new Date()).getFullYear(), month: ((new Date()).getMonth() + 1), day: (new Date()).getDate() };
    this.scheduleAppoint = this.fb.group({
      appDate: [''],
      appTime: [''],
      location: [''],
    });
  }

  saveAppointment(data) {
    let formdata = new FormData();
    const dob = data.appDate;
    let RBL = localStorage.getItem('RBL');
    let RblArray = JSON.parse(RBL);
    let URNumber = RblArray.URNumber;
    let dateVal;
    if (dob) {
      dateVal = `${dob.year}-${padNumber(dob.month)}-${padNumber(dob.day)}`;
    }
    else {
      dateVal = '';
    }
    formdata.append('URNumber', URNumber);
    formdata.append('appDate', dateVal);
    formdata.append('appTime', data.appTime);
    formdata.append('location', data.location);
    this.rblserv.scheduleAppointment(formdata).subscribe(
      res => {
        if (res['status'] == 0) {
          this.formclass = 'success';
          this.msg = res['message'];
          this.rblserv.setAppointmentStep('additionalDetails');
          this.router.navigate(['rbl/additionalDetails']);
        } else {
          this.formclass = 'error';
          this.msg = res['message'];
        }
      },
      error => {
        this.formclass = 'error';

        if (error.error.appDate) {
          this.msg = error.error.appDate;
        } else if (error.error.appTime) {
          this.msg = error.error.appTime;
        } else if (error.error.location) {
          this.msg = error.error.location;
        } else {
          this.msg = '';
          this.formclass = 'success';
        }

      }
    );
  }

  getTimeslotList() {
    this.rblserv.getTimeslotList().subscribe(res => {
      this.timeSlotList = res;
    });
  }

 

}
