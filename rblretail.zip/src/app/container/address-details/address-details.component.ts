import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, Validator } from '@angular/forms';
import { RblserviceService } from '../../services/rblservice.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-address-details',
  templateUrl: './address-details.component.html',
  styleUrls: ['./address-details.component.css']
})
export class AddressDetailsComponent implements OnInit {

  addressDetails: FormGroup;
  states: {};
  res_cities: {};
  ofc_cities: {};
  msg: string;
  formclass;

  residentTabEnabled: boolean;
  residentArea: boolean;
  officeArea: boolean;

  constructor(
    private fb: FormBuilder,
    private rblserv: RblserviceService,
    private router: Router) { }

  ngOnInit() {
    if (!this.rblserv.chkRBLSteps()) {
      this.router.navigate(['/']);
    }

    this.residentTabEnabled = true;

    this.addressDetails = this.fb.group({
      addressLine1: [''],
      addressLine2: [''],
      state: [''],
      city: [''],
      pin: [''],
      district: [''],
      landmark: [''],
      bank: [''],
      accountHolder: [''],
      accountNumber: [''],
      accountType: [''],
      IFSC: [''],
      office_addressLine1: [''],
      office_addressLine2: [''],
      office_city: [''],
      office_state: [''],
      office_pin: [''],
      office_district: [''],
      office_landmark: [''],

    });
    this.rblserv.getStates().subscribe(
      data => {
        this.states = data;
      }
    );

    this.rblserv.getCustomerAddress().subscribe(response => {
      if(response['data']){
        this.onChangeResState(response['data']['Residence']['state']);
        this.onChangeOfcState(response['data']['Office']['state']);
        let accountType = '';
        if(response['data']['BankDetails']['accountType']){
          accountType = response['data']['BankDetails']['accountType'];
        }
        this.addressDetails.setValue({
          addressLine1: response['data']['Residence']['addressLine1'],
          addressLine2: response['data']['Residence']['addressLine2'],
          state: response['data']['Residence']['state'],
          city: response['data']['Residence']['city'],
          pin: response['data']['Residence']['pincode'],
          district: response['data']['Residence']['district'],
          landmark: response['data']['Residence']['landmark'],
          bank: response['data']['BankDetails']['bank'],
          accountHolder: response['data']['BankDetails']['accountHolder'],
          accountNumber: response['data']['BankDetails']['accountNumber'],
          accountType: accountType,
          IFSC: response['data']['BankDetails']['IFSC'],
          office_addressLine1: response['data']['Office']['addressLine1'],
          office_addressLine2: response['data']['Office']['addressLine2'],
          office_city: response['data']['Office']['city'],
          office_state: response['data']['Office']['state'],
          office_pin: response['data']['Office']['pincode'],
          office_district: response['data']['Office']['district'],
          office_landmark: response['data']['Office']['landmark'],
        })
      }
      
      

    });

  }

  saveAddressDetails(data) {

    let formdata = new FormData();
    let RBL = localStorage.getItem('RBL');
    let RblArray = JSON.parse(RBL);
    let URNumber = RblArray.URNumber;
    formdata.append('addressLine1', data.addressLine1);
    formdata.append('addressLine2', data.addressLine2);
    formdata.append('bank', data.bank);
    formdata.append('state', data.state);
    formdata.append('city', data.city);
    formdata.append('pincode', data.pin);
    formdata.append('district', data.district);
    formdata.append('landmark', data.landmark);
    formdata.append('accountHolder', data.accountHolder);
    formdata.append('accountNumber', data.accountNumber);
    formdata.append('accountType', data.accountType);
    formdata.append('IFSC', data.IFSC);
    formdata.append('office_addressLine1', data.office_addressLine1);
    formdata.append('office_addressLine2', data.office_addressLine2);
    formdata.append('office_city', data.office_city);
    formdata.append('office_state', data.office_state);
    formdata.append('office_pincode', data.office_pin);
    formdata.append('office_district', data.office_district);
    formdata.append('office_landmark', data.office_landmark);
    formdata.append('URNumber', URNumber);
    this.rblserv.saveAddressDetails(formdata).subscribe(
      res => {

        if (res['status'] == 0) {
          this.formclass = 'success';
          this.msg = res['message'];
          this.rblserv.setAppointmentStep('scheduleAppointment');
          this.router.navigate(['rbl/scheduleAppointment']);
        } else {
          this.formclass = 'error';
          this.msg = res['message'];
        }

      },
      error => {
        this.formclass = 'error';
        this.residentTabEnabled = true;
        if (error.error.addressLine1) {
          this.msg = error.error.addressLine1;
          document.getElementById('addressLine1').focus();
        } else if (error.error.state) {
          this.msg = error.error.state;
          document.getElementById('state').focus();
        } else if (error.error.city) {
          this.msg = error.error.city;
        } else if (error.error.pincode) {
          this.msg = error.error.pincode;
        } else if (error.error.accountNumber) {
          this.msg = error.error.accountNumber;
        } else if (error.error.accountType) {
          this.msg = error.error.accountType;
        } else if (error.error.IFSC) {
          this.msg = error.error.IFSC;
        } else if (error.error.office_addressLine1) {
          this.residentTabEnabled = false;
          this.msg = error.error.office_addressLine1;
        } else if (error.error.office_state) {
          this.residentTabEnabled = false;
          this.msg = error.error.office_state;
        } else if (error.error.office_city) {
          this.residentTabEnabled = false;
          this.msg = error.error.office_city;
        } else if (error.error.office_pin) {
          this.residentTabEnabled = false;
          this.msg = error.error.office_pin;
        } else {
          this.msg = '';
          this.formclass = 'success';
        }
        let scrollToTop = window.setInterval(() => {
          let pos = window.pageYOffset;
          if (pos > 0) {
            window.scrollTo(0, pos - 50);
          } else {
            window.clearInterval(scrollToTop);
          }
        }, 30);
      }
    )
  }

  onChangeResState(stateId: number) {
    if (stateId) {
      this.rblserv.getCities(stateId).subscribe(
        data => {
          this.res_cities = data
        }
      );
    } else {
      this.res_cities = null;
    }
  }

  setCls(v) {
    this.residentTabEnabled = v;
  }

  onChangeOfcState(stateId: number) {
    if (stateId) {
      this.rblserv.getCities(stateId).subscribe(
        data => {
          this.ofc_cities = data
        }
      );
    } else {
      this.ofc_cities = null;
    }
  }




}
