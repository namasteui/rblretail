import { Component, OnInit } from '@angular/core';
import { RblserviceService } from '../../services/rblservice.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-get-otp',
  templateUrl: './get-otp.component.html',
  styleUrls: ['./get-otp.component.css']
})
export class GetOtpComponent implements OnInit {

  URNumber:String;
  retailer_name;
  mobile_number;
  approved_credit_limit;
  success = true;
  error_msg;
  formclass;
  msg;
  constructor(
    private rblserv: RblserviceService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    const urn = this.route.snapshot.params['urn'];
    this.OTPPage(urn);
  }

  OTPPage(urn){
    this.URNumber = btoa(urn);
    this.rblserv.getCustomer(this.URNumber)
    .subscribe( 
      res => {
      if(res && res['status'] == 0){
        this.retailer_name = res['data']['retailer_name'];
        this.mobile_number = res['data']['mobile_number'];
        this.approved_credit_limit = res['data']['approved_credit_limit'] || 0;

        let RBL:any = {};
        RBL.retailer_name = res['data']['retailer_name'];  
        RBL.URNumber = res['data']['URNumber'];
        RBL.mobile_number = res['data']['mobile_number'];      
        localStorage.setItem('RBL', JSON.stringify(RBL));

        this.rblserv.setAppointmentStep('home');
      } else {
        this.success = false;
        this.error_msg = res['message'];
      }
    },
    error => {
      this.success = false;
      this.error_msg = 'Sorry! Something went wrong.';
    }
    );
  }

  getOTP(){
    this.rblserv.getOtp().subscribe(
      res=>{
        if(res['status'] == 0){
          this.formclass = 'success';
          this.msg = res['message'];

          let RBL = localStorage.getItem('RBL');
          let RblArray = JSON.parse(RBL);
          RblArray.referenceNum = res['data']['referenceNum'];
          localStorage.setItem('RBL', JSON.stringify(RblArray));         

          this.rblserv.setAppointmentStep('verifyOtp');
          this.router.navigate(['rbl/verifyOtp']);          
        } else {
          this.formclass = 'error';
          this.msg = res['message'];
        }        
      }
    )
    
  }

}
