import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, Validator } from '@angular/forms';
import { RblserviceService } from '../../services/rblservice.service';
import { Router } from '@angular/router';

import { NgbDatepickerConfig, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { padNumber, NgbDateCustomParserFormatter, ltrim } from '../../core/util/ngb-date-customer-parser-format';

@Component({
  selector: 'app-about-yourself',
  templateUrl: './about-yourself.component.html',
  styleUrls: ['./about-yourself.component.css'],
  providers: [{ provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }]
})
export class AboutYourselfComponent implements OnInit {

  formclass;
  msg;
  aboutYourSelf: FormGroup;
  maxDate;
  annualTurnOver: {};
  constructor(
    private fb: FormBuilder,
    private rblserv: RblserviceService,
    private router: Router) {

  }

  ngOnInit() {
    if (!this.rblserv.chkRBLSteps()) {
      this.router.navigate(['/']);
    }

    let todaysDt = padNumber((new Date()).getDate()) + '/' + padNumber(((new Date()).getMonth() + 1)) + '/' + (new Date()).getFullYear();
    this.maxDate = { year: (new Date()).getFullYear(), month: ((new Date()).getMonth() + 1), day: (new Date()).getDate() };
    this.aboutYourSelf = this.fb.group({
      name: [''],
      dob: [''],
      gender: [''],
      pan: [''],
      mobile: [''],
      email: [''],
      annualTurnover: ['']
    });

    this.rblserv.getCustomerData().subscribe(response => {
      let dobDate = response['data']['dob'] || '';
      let dobDateobj = {};
      if(dobDate){
        dobDate = dobDate.split("-");
        let y = parseInt(dobDate[0]);
        let m = parseInt(ltrim(dobDate[1], '0'));
        let d = parseInt(ltrim(dobDate[2], '0'));
        dobDateobj = {year: y, month: m, day: d};
      } 

      let gender = '';
      let annualTurnover = '';

      if(response['data']['gender']){
        gender = response['data']['gender'];
      }
      if(response['data']['annualTurnover']){
        annualTurnover = response['data']['annualTurnover'];
      }

      this.aboutYourSelf.setValue({
        name: response['data']['name'],
        dob: dobDateobj,
        gender: gender,
        pan: response['data']['pan'],
        mobile: response['data']['mobile'],
        email: response['data']['email'],
        annualTurnover: annualTurnover
      });
    })

    this.rblserv.getTurnoverList().subscribe(res=>{
     if(res){
      this.annualTurnOver = res
     }
    });

  }

  saveCustomerDetails(data) {
    let formdata = new FormData();
    let RBL = localStorage.getItem('RBL');
    let RblArray = JSON.parse(RBL);
    let URNumber = RblArray.URNumber;

    const dob = data.dob;
    let bdate;
    if (data.dob) {
      bdate = `${dob.year}-${padNumber(dob.month)}-${padNumber(dob.day)}`;
    }
    else {
      bdate = '';
    }

    formdata.append('name', data.name);
    formdata.append('dob', bdate);
    formdata.append('gender', data.gender);
    formdata.append('pan', data.pan);
    formdata.append('mobile', data.mobile);
    formdata.append('email', data.email);
    formdata.append('annualTurnover', data.annualTurnover);
    formdata.append('URNumber', URNumber);

    this.rblserv.aboutYourSelf(formdata)
      .subscribe(
        res => {
          if (res['status'] == 0) {
            this.formclass = 'success';
            this.msg = res['message'];
            this.rblserv.setAppointmentStep('creditLimit');
            this.router.navigate(['rbl/creditLimit']);
          } else {
            this.formclass = 'error';
            this.msg = res['message'];
          }
        },
        error => {
          this.formclass = 'error';
          if (error.error.name) {
            this.msg = error.error.name;
          } else if (error.error.dob) {
            this.msg = error.error.dob;
          } else if (error.error.gender) {
            this.msg = error.error.gender;
          } else if (error.error.pan) {
            this.msg = error.error.pan;
          } else if (error.error.mobile) {
            this.msg = error.error.mobile;
          } else if (error.error.email) {
            this.msg = error.error.email;
          } else if (error.error.annualTurnover) {
            this.msg = error.error.annualTurnover;
          } else {
            this.msg = '';
          }
        }
      );

  }


}
