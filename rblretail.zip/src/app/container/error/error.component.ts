import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {
  error_msg;
  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    
    this.route.url.subscribe(params => {
      if(params.length){
        const path = params[2].path;   
        console.log(params)
        switch(path) { 
          case "U": { 
            this.error_msg = 'Your profile is already registered with us.';
            break; 
          }  
          default: { 
            this.error_msg = 'Sorry! Something went wrong.';
            break;              
          } 
       }
      }    
    });
  }

}
