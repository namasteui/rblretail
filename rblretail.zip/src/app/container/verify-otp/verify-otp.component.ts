import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,FormControl,Validators, Validator } from '@angular/forms';
import { Router } from '@angular/router';
import { RblserviceService } from '../../services/rblservice.service';

@Component({
  selector: 'app-verify-otp',
  templateUrl: './verify-otp.component.html',
  styleUrls: ['./verify-otp.component.css']
})
export class VerifyOtpComponent implements OnInit {
  timercount = 60;
  myVar;
  mobile_number;
  resendLink;
  formclass;
  msg;
  constructor(
    private router: Router,
    private rblserv: RblserviceService
  ) { }

  ngOnInit() {
    if(!this.rblserv.chkRBLSteps()){
      this.router.navigate(['/']);
    } else {
      this.timerCount();
      this.resendLink = false;
      let RBL = localStorage.getItem('RBL');
      let RblArray = JSON.parse(RBL);
      let mobile_number = RblArray.mobile_number;
      mobile_number = mobile_number.toString();
      mobile_number = 'XXXXXXXX' + mobile_number.substr(mobile_number.length -2);
      this.mobile_number =  mobile_number;
    }    
  }

  timerCount(){
    this.myVar = setInterval(() => {
      this.timercount--; 
      if(this.timercount == 0){
        clearInterval(this.myVar);
        this.resendLink = true;
      }
    }, 1000);
  }

  ValidatePassKey(v,i){
    if(v.length && (i > 0 && i < 6)){
      document.getElementById(i + 1).focus();
    }
  }

  verifyOTP(v){
    let otp = v.value.a1 + '' + v.value.a2 + '' + v.value.a3 + '' + v.value.a4 + '' + v.value.a5 + '' + v.value.a6;
    let URNumber = this.rblserv.getURNumber();
    let RblArray = this.rblserv.getRBLArr();
    let referenceNum = RblArray.referenceNum;

    let formdata = new FormData();
    formdata.append('otp', otp);
    formdata.append('URNumber', URNumber);
    formdata.append('referenceNum', referenceNum);

    this.rblserv.verifyOTP(formdata)
    .subscribe( 
      res => {
        if(res['status'] == 0 && res['session'] == 1){
          this.formclass = 'success';
          this.msg = res['message'];

          let RBL = localStorage.getItem('RBL');
          let RblArray = JSON.parse(RBL);
          RblArray.session = res['session'];
          delete RblArray.referenceNum;
          localStorage.setItem('RBL', JSON.stringify(RblArray)); 
          clearInterval(this.myVar);
          this.rblserv.setAppointmentStep('customerDetails');
          this.router.navigate(['rbl/customerDetails']);
        } else {
          v.reset();
          this.formclass = 'error';
          this.msg = res['message'];
        }
      },
      error => {
        this.formclass = 'error';
        if(error.error.otp){
          this.msg = error.error.otp;
        } else if(error.error.URNumber){
          this.msg = 'Sorry! Something went wrong.';
        } else if(error.error.referenceNum){
          this.msg = 'Sorry! Something went wrong.';
        } else {
          this.msg = '';
        }         
      }
    );
  }

  resendOTP(v){
    this.rblserv.getOtp().subscribe(
      res=>{
        if(res['status'] == 0){
          let RBL = localStorage.getItem('RBL');
          let RblArray = JSON.parse(RBL);
          RblArray.referenceNum = res['data']['referenceNum'];
          localStorage.setItem('RBL', JSON.stringify(RblArray));         

          v.reset();
          clearInterval(this.myVar);
          this.timercount = 60;
          this.timerCount();    
          this.resendLink = false;
          
        } else {
          this.formclass = 'error';
          this.msg = res['message'];
        }        
      }
    )
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

}
