import { TestBed } from '@angular/core/testing';

import { RblserviceService } from './rblservice.service';

describe('RblserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RblserviceService = TestBed.get(RblserviceService);
    expect(service).toBeTruthy();
  });
});
