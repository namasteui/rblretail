import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RblserviceService {

  constructor(private http: HttpClient) { }

  getURNumber(){
    let RBL = localStorage.getItem('RBL');
    let RblArray = JSON.parse(RBL);
    let URNumber = RblArray.URNumber;
    return URNumber;
  }

  getRBLArr(){
    let RBL = localStorage.getItem('RBL');
    let RblArray = JSON.parse(RBL);
    return RblArray;
  }

  getCustomer(URNumber) {
    return this.http.get(`${environment.RblRetailLoanURL}` + '/OTPPage/' + URNumber);
  }

  getOtp(){
    let URNumber = btoa(this.getURNumber());
    return this.http.get(`${environment.RblRetailLoanURL}` + '/otpGen/' + URNumber);
  }

  aboutYourSelf(post){
    return this.http.post(`${environment.RblRetailLoanURL}` +'/saveCustomerBasic', post);
  }

  verifyOTP(post){
    return this.http.post(`${environment.RblRetailLoanURL}` +'/otpVal', post);
  }

  getCreditLimit() {
    let URNumber = btoa(this.getURNumber());
    return this.http.get(`${environment.RblRetailLoanURL}` + '/creditLimit/' + URNumber);
  }

  limitAcceptance(){
    let URNumber = btoa(this.getURNumber());
    return this.http.get(`${environment.RblRetailLoanURL}` + '/limitAcceptance/' + URNumber);
  }

  getStates(){
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getStateList');
  }

  getCities(stateId: number){
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getCityList/' + stateId);
  }

  saveAddressDetails(post){
    return this.http.post(`${environment.RblRetailLoanURL}` + '/saveAddressDetails', post);
  }

  saveAdditionalDetails(post){
    return this.http.post(`${environment.RblRetailLoanURL}` + '/saveAdditionalDetails', post);
  }

  scheduleAppointment(post){
    return this.http.post(`${environment.RblRetailLoanURL}` + '/scheduleAppointment', post);
  }

  getAppointmentSchedule(){
    let URNumber = btoa(this.getURNumber());
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getAppointmentSchedule/' + URNumber);
  }

  setAppointmentStep(k){
    if (localStorage.hasOwnProperty("RSTEP") && k) {
      let RSTEP = localStorage.getItem('RSTEP');
      let RSTEPArray = JSON.parse(RSTEP);
      RSTEPArray[k] = true;
      localStorage.setItem('RSTEP', JSON.stringify(RSTEPArray));
    } else {
      let step = {
        'home': false,
        'verifyOtp': false,
        'customerDetails': false,
        'creditLimit': false,
        'addressDetails': false,
        'scheduleAppointment': false,
        'additionalDetails': false
      }
      localStorage.setItem('RSTEP', JSON.stringify(step));
    }
  }

  chkRBLSteps(){
    if (localStorage.hasOwnProperty("RBL")) {
      let URNumber = this.getURNumber();
      return URNumber;
    } else {
      return false;
    }
  }

  getApplicationStatus(){
    let URNumber = btoa(this.getURNumber());
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getApplicationStatus/' + URNumber);
  }

  getCustomerData(){
    let URNumber = btoa(this.getURNumber());
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getCustomerData/' + URNumber);
  }
  
  getCustomerAddress(){
    let URNumber = btoa(this.getURNumber());
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getCustomerAddress/' + URNumber);
  }
  
  getTurnoverList(){
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getTurnoverList');
  }

  getReligionList(){
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getReligionList');
  }

  getTimeslotList(){
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getTimeslotList');
  }

  getEducationList(){
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getEducationList');
  }

  getCategoryList(){
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getCategoryList');
  }

  getOccupationList(){
    return this.http.get(`${environment.RblRetailLoanURL}` + '/getOccupationList');
  }
}
